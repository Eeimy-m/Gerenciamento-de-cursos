#include<stdio.h>
#include<stdlib.h>
#include<string.h>

struct aluno {
    char nome[40], dataNascimento[10], sexo, emails[10][40], telefones[10][14], cpf[14]; //CPF é único por aluno 
    //int quantEmails, quantTelefones;
};

struct curso {
    char codigo[10], descricao[60]; //código é único por curso
    float preco, cargaHoraria;
};

struct matricula {//Não pode existir mais de um mesmo cpf com um mesmo código de curso
    float desconto;
    char codigoCurso[10], dataInicio, dataFim, cpfAluno[14];
};

int incluirAluno(struct aluno listaAlunos[], int *quant) {
    int quantEmails = 0, i, quantTelefones = 0;
    printf("\nNome: ");
    getchar();
    fgets(listaAlunos[*quant].nome, 40, stdin);
    listaAlunos[*quant].nome[strcspn(listaAlunos[*quant].nome, "\n")] = '\0';

    printf("\nData de nascimento (dd/mm/aaaa): ");
    scanf("%s", &listaAlunos[*quant].dataNascimento);

    printf("\nSexo: ");
    getchar();
    scanf("%c", &listaAlunos[*quant].sexo);

    printf("\nInforme a quantidade de e-mails a serem inseridos: ");
    scanf("%d", &quantEmails);
    printf("\nInsira a seguir o(s) e-mail(s) do aluno: ");
    for(i = 0; i < quantEmails; i++) {
        scanf("%s", &listaAlunos[*quant].emails[i]);
    }
    printf("\n");
    printf("\ne-mail(s) inserido(s) com sucesso.");
    printf("\n");

    printf("\nInforme a quantidade de números telefônicos: ");
    scanf("%d", &quantTelefones);
    printf("\nInsira a seguir o(s) telefone(s): ");
    for(i = 0; i < quantTelefones; i++) {
        scanf("%s", &listaAlunos[*quant].telefones[i]);
    }

    printf("Telefone(s) inserido(s) com sucesso.");
    printf("\n");

    (*quant)++;
    return 1;
}

int incluirCurso(struct curso listaCursos[], int *quantCursos) {
    printf("\nDescrição do curso: ");
    getchar();
    fgets(listaCursos[*quantCursos].descricao, 60, stdin);
    printf("\nCarga horária: ");
    scanf("%f", &listaCursos[*quantCursos].cargaHoraria);
    printf("\nPreço: ");
    scanf("%f", &listaCursos[*quantCursos].preco);
    (*quantCursos)++;
    return 1;
}

int verificarCPF(struct aluno listaAlunos[], char *cpf, int quantAlunos) { //Não está identificando strings iguais
    int i, resultado; 
    if(quantAlunos == 0) {
        return -1;
    }
    else {
        for(i = 0; i < quantAlunos; i++) {
            /*printf("\nQuantAlunos != 0"); 
            printf("\n%s", listaAlunos[i].cpf);*/

            int result = strcmp(cpf, listaAlunos[i].cpf);
            printf("\n%d", result);
            if(strcmp(cpf, listaAlunos[i].cpf) == 0) { //!!!!Não está entrando no if mesmo quando as strings são iguais
                return i;
            }
        }
        return -1; //não foi encontrado
    }
}

int verificarCodigo(struct curso listaCursos[], char codigo[], int quantCursos) {
    int i, j, resultado;
    if(quantCursos == 0) {
        return -1;
    }
    else {
        for(i = 0; i < quantCursos; i++) {
            resultado = strcmp(codigo, listaCursos[i].codigo);
            if(resultado == 0) {
                return i;
            }
        }
        return -1;
    }
}

void submenu(int *opcao) {
    printf("\n1- Listar todos");
    printf("\n2- Listar um");
    printf("\n3- Incluir");
    printf("\n4- Alterar e excluir");
    printf("\n=============================");
    printf("\n");
    printf("\nSelecione uma das opções acima: ");
    scanf("%d", opcao);
}

void submenuRelatorios(int *opcao) {
    printf("\n=============================");
    printf("\nSubmenu Relatórios:");
    printf("\n1- Mostrar dados de todos os alunos de um curso");
    printf("\n2- Mostrar os dados de todos os cursos oferecidos entre as datas X e Y");
    printf("\n3- Mostrar os dados de todos os cursos realizados por um aluno");
    printf("\n=============================");
    printf("\n");
    printf("\nSelecione uma das opções:");
    scanf("%d", opcao);
}

void mainMenu() {
    int opcao, limiteAlunos = 100, limiteCursos = 50, quantAlunos = 0, quantCursos = 0, resultado;
    char *cpf, *codigo;

    struct aluno *alunos; 
    struct curso *cursos;

    do {
        printf("\n=============================");
        printf("\nMenu principal:");
        printf("\n1- Submenu de Alunos");
        printf("\n2- Submenu de Cursos");
        printf("\n3- Submenu de Matrícula");
        printf("\n4- Submenu Relatórios");
        printf("\n5- Sair");
        printf("\n=============================");
        printf("\n");
        printf("\nSelecione uma das opções acima: ");
        scanf("%d", &opcao);

        if(opcao == 1) {
            alunos = (struct aluno *) malloc (limiteAlunos * sizeof(struct aluno));
            if(alunos != NULL) {
                printf("\n=============================");
                printf("\nSubmenu de Alunos");
                submenu(&opcao);
                switch (opcao) {
                    case 1:
                        printf("\nVocê selecionou 1"); //Placeholder 
                    case 2:
                        printf("\nVoce selecionou 2");
                    case 3:
                        system("clear||cls");

                        printf("\nIncluindo aluno no sistema...");
                        printf("\n");
                        printf("\nInforme o CPF do aluno: ");

                        cpf = (char *) malloc(sizeof (char) * 16); 
                        if(cpf != NULL) {
                            getchar();
                            fgets(cpf, 15, stdin);
                            cpf[strcspn(cpf, "\n")] = '\0';
                            //scanf("%15s", cpf);
                            if(verificarCPF(alunos, cpf, quantAlunos) >= 0) {
                                printf("\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                                printf("\nO CPF inserido já existe no sistema.");
                                printf("\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                                printf("\n");
                            }
                            else {
                                strcpy(alunos[quantAlunos].cpf, cpf);
                                //printf("\n%s", alunos[quantAlunos].cpf);
                                //free(cpf);
                                resultado = incluirAluno(alunos, &quantAlunos);
                                if(resultado == 1) { //feedback
                                    //system("clear||cls");

                                    printf("\n=============================");
                                    printf("\nAluno adicionado ao sistema com sucesso!");
                                    printf("\n=============================");
                                    printf("\n");
                                }
                                else {
                                    printf("\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                                    printf("\nNão foi possível adicionar o aluno ao sistema.");
                                    printf("\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                                    printf("\n");
                                }
                            }
                        } 
                        else {
                            printf("\nMemória indisponível.");
                        }
                        break;
                    case 4:
                        printf("\nVoce selecionou 4");
                    default:
                        system("clear||cls");
                        printf("\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                        printf("\nA opção inserida não é válida, tente novamente.");
                        printf("\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                        printf("\n");
                }
            }
            else {
                printf("\nMemória insuficiente");
            }
        }
        else if(opcao == 2) {
            cursos = (struct curso*) malloc (limiteCursos * sizeof(struct curso));
            if(cursos != NULL) {
                printf("\n=============================");
                printf("\nSubmenu de Cursos:");
                submenu(&opcao);
                switch (opcao) {
                    case 1:
                        printf("\nVoce selecionou 1");
                    case 2:
                        printf("\nVoce selecionou 2");
                    case 3:
                        printf("\nInsira o código do curso a ser inserido no sistema: ");
                        codigo = (char *) malloc(12);
                        if(codigo != NULL) {
                            scanf("%11s", &codigo);   
                            if(verificarCodigo(cursos, codigo, quantCursos) >= 0) {
                                printf("\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                                printf("\nO código inserido já existe no sistema.");
                                printf("\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                                printf("\n");
                            }
                            else {
                                strcpy(cursos[quantCursos].codigo, codigo);
                                resultado = incluirCurso(cursos, &quantCursos);
                                if(resultado == 1) { //confirma se o processo de incluir foi terminado
                                    system("clear||cls");
                                    printf("\n=============================");
                                    printf("\nCurso cadastrado com sucesso!");
                                    printf("\n=============================");
                                    printf("\n");
                                }
                            }
                        }
                        else {
                            printf("\nmemória indisponível.");
                        }
                    case 4:
                        printf("\nVoce selecionou 4");
                }
            }
            else {
                printf("\nMemória insuficiente");
            }
        }
        else if(opcao == 3) {
            printf("\n=============================");
            printf("Submenu de Matrícula");
            submenu(&opcao);
        }
        else if(opcao == 4) {
            printf("\n=============================");
            printf("Submenu de Relatórios");
            submenuRelatorios(&opcao);
        }
    }
    while(opcao != 5);
    if(opcao == 5) {
    system("clear||cls");
    printf("\n");
    printf("\n=============================");
    printf("\nEncerrando programa.");
    printf("\n=============================");
    }
}

int main() {
    mainMenu();
}